# Kalos Bot (Elysium testnet)

Bot harian untuk **satu wallet** di [kalos.fun](https://www.kalos.fun). Jalan sekali sehari di jam acak, urutan aksi diacak, ada jeda acak antar transaksi.

## Fitur
| Modul | Nambah poin? | Keterangan |
|---|---|---|
| Check-in harian | ✅ (pool check-in) | `POST /v2/points/checkin` |
| Beli NFT murah + relist | ✅ | Beli listing termurah ≤ `NFT_MAX_BUY_PRICE`, lalu list ulang +markup |
| Terima offer | ✅ | Jual NFT hasil beli bot kalau ada offer ≥ 90% harga beli |
| Mint Drops | ✅ | Mint drop public (tanpa allowlist) ≤ `DROP_MAX_MINT_PRICE` |
| Like post | ✅ | Like acak post di feed global |
| Post | ✅ | Ambil acak dari `posts.txt` (default **off**) |
| Swap HYPE → KALOS | ❌ | Uniswap v3 router Kalos |
| Add LP KALOS/WHYPE | ❌ | Full range, pool fee 0.01% |
| Laporan Telegram | – | Ringkasan aksi, saldo, poin & rank |

## Persiapan
1. Install **Node.js 18+** (disarankan 20/22).
2. Buat wallet EVM **baru** khusus testnet, import ke Rabby/MetaMask.
3. Buka link referral di browser, connect wallet itu, **daftar username** (wajib, bot tidak bisa daftar sendiri).
4. Ambil test HYPE di https://elysium.kinetiq.xyz/testnet-faucet (manual).

## Install & jalan
```bash
cd kalos-bot
npm install
cp .env.example .env      # lalu edit .env, isi PRIVATE_KEY
npm run status            # cek wallet, saldo, akun, poin
npm run once              # jalan 1 sesi sekarang (tes)
npm start                 # mode otomatis, sekali sehari di jam acak
```

Biar jalan terus di VPS:
```bash
npm i -g pm2
pm2 start src/index.js --name kalos-bot
pm2 logs kalos-bot
pm2 save && pm2 startup
```

## Telegram (opsional)
1. Chat @BotFather → `/newbot` → salin token ke `TELEGRAM_BOT_TOKEN`.
2. Kirim pesan apa saja ke bot kamu, buka `https://api.telegram.org/bot<TOKEN>/getUpdates`, salin `chat.id` ke `TELEGRAM_CHAT_ID`.

## File
- `.env` setting & private key (jangan dibagikan)
- `posts.txt` daftar kalimat untuk post (satu baris satu post)
- `state.json` catatan NFT yang dibeli bot (dibuat otomatis)
- `logs/` log harian

## Catatan
- Poin dihitung harian, update jam 07:00 WIB. Bobot tiap aksi tidak dipublikasikan.
- Floor kebanyakan koleksi > 0.2 HYPE. Kalau "tidak ada NFT yang cocok", naikkan `NFT_MAX_BUY_PRICE` atau isi `NFT_COLLECTIONS`.
- Belum ada token/airdrop yang dikonfirmasi Kalos. Pakai dengan risiko sendiri, satu wallet saja.
- Alamat kontrak diambil dari config resmi Kalos per 25 Okt 2026. Kalau Kalos upgrade kontrak, update `src/config.js`.

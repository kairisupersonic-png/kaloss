import fs from 'node:fs';
import path from 'node:path';
import { CFG } from './config.js';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const LOG_DIR = path.join(ROOT, 'logs');
const STATE_FILE = path.join(ROOT, 'state.json');
fs.mkdirSync(LOG_DIR, { recursive: true });

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const rand = (a, b) => a + Math.random() * (b - a);
export const randInt = (a, b) => Math.floor(rand(a, b + 1));
export const shuffle = (arr) => arr.map((v) => [Math.random(), v]).sort((x, y) => x[0] - y[0]).map((x) => x[1]);
export const humanDelay = () => sleep(rand(CFG.delay.min, CFG.delay.max) * 1000);

export function wibNow() {
  const d = new Date(Date.now() + 7 * 3600_000);
  return { iso: d.toISOString().replace('T', ' ').slice(0, 19), date: d.toISOString().slice(0, 10), hour: d.getUTCHours() };
}

export function log(...args) {
  const line = `[${wibNow().iso} WIB] ${args.map((a) => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}`;
  console.log(line);
  fs.appendFileSync(path.join(LOG_DIR, `${wibNow().date}.log`), line + '\n');
}

export function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { return { bought: {}, lastRunDate: null }; }
}
export function saveState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2)); }

export function readPosts() {
  try { return fs.readFileSync(path.join(ROOT, 'posts.txt'), 'utf8').split('\n').map((s) => s.trim()).filter(Boolean); } catch { return []; }
}

export async function telegram(text) {
  const { token, chatId } = CFG.telegram;
  if (!token || !chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: true }),
    });
  } catch (e) { log('⚠️ Telegram gagal:', e.message); }
}

export async function retry(fn, label, tries = 3) {
  for (let i = 1; ; i++) {
    try { return await fn(); } catch (e) {
      if (i >= tries) throw e;
      log(`↻ ${label} gagal (${e.shortMessage || e.message}), coba lagi ${i}/${tries - 1}`);
      await sleep(5000 * i);
    }
  }
}

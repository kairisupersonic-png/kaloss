import { NET } from './config.js';
import { log, retry } from './util.js';

// Klien API Kalos (sama seperti yang dipakai website): SIWE sign-in -> Bearer token.
export class KalosApi {
  constructor(wallet) { this.wallet = wallet; this.token = null; this.expiresAt = 0; }

  async request(method, path, { body, auth = false } = {}) {
    if (auth) await this.ensureSession();
    const headers = { Accept: 'application/json', Origin: 'https://www.kalos.fun' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (auth) headers.Authorization = 'Bearer ' + this.token;
    const res = await fetch(NET.api + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const text = await res.text();
    let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (res.status === 401 && auth) { this.token = null; }
    if (!res.ok) {
      const err = new Error(`${method} ${path} -> ${res.status} ${data?.message || data?.error || text?.slice(0, 120)}`);
      err.status = res.status; err.data = data; throw err;
    }
    return data;
  }
  get(path, opts) { return retry(() => this.request('GET', path, opts), `GET ${path}`); }
  send(method, path, body) { return this.request(method, path, { body, auth: true }); }

  async ensureSession() {
    if (this.token && Date.now() < this.expiresAt - 60_000) return;
    const address = this.wallet.address;
    const nonce = await this.request('POST', '/v2/auth/nonce', { body: { address } });
    const message = nonce?.message;
    if (typeof message !== 'string' || !message.toLowerCase().includes(address.toLowerCase()) || !message.includes(`Chain ID: ${NET.chainId}`)) {
      throw new Error('Pesan sign-in dari Kalos tidak sesuai, dibatalkan demi keamanan.');
    }
    const signature = await this.wallet.signMessage(message);
    const r = await this.request('POST', '/v2/auth/verify', { body: { message, signature } });
    this.token = r.token;
    this.expiresAt = Number(r.expiresAt) > 1e12 ? Number(r.expiresAt) : Number(r.expiresAt) * 1000;
    log('🔑 Sign-in Kalos berhasil');
  }

  me() { return this.request('GET', '/v2/me', { auth: true }); }
  market() { return this.get('/v2/market'); }
  checkinStatus() { return this.request('GET', '/v2/points/me/checkin', { auth: true }); }
  checkin() { return this.send('POST', '/v2/points/checkin', {}); }
  pointsRow(period) { return this.get(`/v2/points?period=${period}&limit=1&offset=0&address=${this.wallet.address.toLowerCase()}`); }
  feed(page = 0) { return this.request('GET', `/v2/social/feed?view=global&type=posts&page=${page}`, { auth: true }); }
  like(key) { return this.send('PUT', `/v2/social/likes/${encodeURIComponent(key)}`); }
  post(text) { return this.send('POST', '/v2/social/posts', { text, collection: null }); }
}

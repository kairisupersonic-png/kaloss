import 'dotenv/config';

const bool = (k, d = false) => (process.env[k] ?? String(d)).trim().toLowerCase() === 'true';
const num = (k, d) => { const v = Number(process.env[k]); return Number.isFinite(v) && process.env[k] !== '' ? v : d; };
const str = (k, d = '') => (process.env[k] ?? d).trim();

if (!/^0x[0-9a-fA-F]{64}$/.test(str('PRIVATE_KEY'))) {
  console.error('❌ PRIVATE_KEY di .env belum diisi / formatnya salah (harus 0x + 64 karakter hex).');
  process.exit(1);
}

export const CFG = {
  privateKey: str('PRIVATE_KEY'),
  window: { start: num('RUN_WINDOW_START', 8), end: num('RUN_WINDOW_END', 23) },
  enable: {
    checkin: bool('ENABLE_CHECKIN', true),
    nftTrade: bool('ENABLE_NFT_TRADE', true),
    acceptBids: bool('ENABLE_ACCEPT_BIDS', true),
    drops: bool('ENABLE_DROPS', true),
    likes: bool('ENABLE_LIKES', true),
    posts: bool('ENABLE_POSTS', false),
    swap: bool('ENABLE_SWAP', true),
    lp: bool('ENABLE_LP', true),
  },
  nft: {
    maxBuy: num('NFT_MAX_BUY_PRICE', 0.05),
    buysPerDay: num('NFT_BUYS_PER_DAY', 2),
    markup: num('NFT_RELIST_MARKUP', 0.05),
    acceptRatio: num('ACCEPT_BID_MIN_RATIO', 0.9),
    collections: str('NFT_COLLECTIONS').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
  },
  drops: { maxPrice: num('DROP_MAX_MINT_PRICE', 0.02), qty: num('DROP_MINT_QTY', 1) },
  social: { likes: num('LIKES_PER_DAY', 5), posts: num('POSTS_PER_DAY', 1) },
  dex: { swapHype: num('SWAP_HYPE_AMOUNT', 0.01), lpHype: num('LP_HYPE_AMOUNT', 0.01), slippageBps: num('SLIPPAGE_BPS', 300) },
  minReserve: num('MIN_HYPE_RESERVE', 0.05),
  delay: { min: num('DELAY_MIN_SEC', 20), max: num('DELAY_MAX_SEC', 90) },
  telegram: { token: str('TELEGRAM_BOT_TOKEN'), chatId: str('TELEGRAM_CHAT_ID') },
};

// Alamat dari config resmi frontend Kalos (www.kalos.fun/live-config.js & /v2/dex/config), Elysium testnet.
export const NET = {
  chainId: 99801,
  rpc: 'https://testnet-rpc.elysium.kinetiq.xyz',
  explorer: 'https://elysium.kinetiq.xyz/testnet-explorer',
  api: 'https://api.kalos.fun',
  marketplace: '0x0FF8b7afC288AC42f82320f54a49c400f233bF07',
  marketWhype: '0x41051f27c609dB70af05b7128f15155Dc8E49Ac7', // payment token marketplace
  dex: {
    swapRouter: '0x752f6816Bc514e1Eeff852b2eAdcd96f6c0F9f3f',
    positionManager: '0x28580f9baeDDBc88D3Daca542aF12271E52B5765',
    quoterV2: '0x2b555398ac8BAf5d4B541EF12E565eF312739149',
    whype: '0xCD57F65c2B0e5881CFC2E609F7CD53b746E1F234', // WHYPE versi DEX (beda dengan marketplace)
    kalos: '0x8a2201953AF29e8BE7700bcB53dA3ce5caD18726',
    kalosWhypePool: '0x30b402C6429Ecea14fc1e0a8963EBBedd5B920C1', // fee 0.01%, paling ramai
  },
};

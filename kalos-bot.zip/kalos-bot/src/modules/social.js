import { CFG } from '../config.js';
import { log, humanDelay, shuffle, readPosts, sleep } from '../util.js';

/** Cari semua id post (format "post-123") di respons feed, apa pun bentuk JSON-nya. */
function collectPosts(node, me, out = new Map()) {
  if (Array.isArray(node)) { node.forEach((n) => collectPosts(n, me, out)); return out; }
  if (!node || typeof node !== 'object') return out;
  const id = typeof node.id === 'string' && /^post-\d{1,18}$/.test(node.id) ? node.id : null;
  if (id) {
    const author = String(node.author?.address || node.author || node.address || node.actor || '').toLowerCase();
    const liked = node.liked === true || node.viewer?.liked === true;
    if (author !== me && !liked) out.set(id, node);
  }
  Object.values(node).forEach((v) => { if (v && typeof v === 'object') collectPosts(v, me, out); });
  return out;
}

export async function runLikes(api, report) {
  let posts = new Map();
  for (let attempt = 0; attempt < 3 && !posts.size; attempt++) {
    try {
      for (let page = 0; page < 2; page++) collectPosts(await api.feed(page), api.wallet.address.toLowerCase(), posts);
    } catch (e) {
      log('⚠️ Feed belum bisa dibaca:', e.message);
      await sleep(20_000);
    }
  }
  const targets = shuffle([...posts.keys()]).slice(0, CFG.social.likes);
  let ok = 0;
  for (const id of targets) {
    try { await api.like(id); ok++; log(`❤️ Like ${id}`); } catch (e) { log(`⚠️ Like ${id} gagal:`, e.message); }
    await humanDelay();
  }
  report.push(`❤️ Like ${ok}/${targets.length} post`);
}

export async function runPosts(api, report) {
  const lines = shuffle(readPosts());
  let ok = 0;
  for (const text of lines.slice(0, CFG.social.posts)) {
    try { await api.post(text); ok++; log(`📝 Post: ${text}`); } catch (e) { log('⚠️ Post gagal:', e.message); }
    await humanDelay();
  }
  report.push(`📝 Post ${ok}`);
}

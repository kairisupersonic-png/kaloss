import { CFG, NET } from '../config.js';
import { log, humanDelay, shuffle, saveState } from '../util.js';
import { wallet, contract, MARKET_ABI, NFT_ABI, sendTx, canSpend, ensureNftApproval, fmt, parse } from '../chain.js';

const lc = (a) => String(a || '').toLowerCase();
const now = () => Math.floor(Date.now() / 1000);

function allowedCollections(market) {
  return new Map(market.collections
    .filter((c) => c.approval === 1 && (!CFG.nft.collections.length || CFG.nft.collections.includes(lc(c.slug))))
    .map((c) => [lc(c.address), c]));
}

/** Beli NFT termurah (di bawah batas harga), lalu relist dengan markup. */
export async function runNftTrade(market, state, report) {
  const market$ = contract(NET.marketplace, MARKET_ABI);
  const cols = allowedCollections(market);
  const max = parse(CFG.nft.maxBuy);
  const me = lc(wallet.address);

  let candidates = market.listings
    .filter((l) => cols.has(lc(l.nft)) && lc(l.seller) !== me && Number(l.expiration) > now() + 600)
    .filter((l) => lc(l.paymentToken) === lc(NET.marketWhype) && BigInt(l.price) > 0n && BigInt(l.price) <= max)
    .sort((a, b) => (BigInt(a.price) < BigInt(b.price) ? -1 : 1))
    .slice(0, 30);
  candidates = shuffle(candidates);
  log(`🛒 ${candidates.length} listing di bawah ${CFG.nft.maxBuy} HYPE`);

  let bought = 0;
  for (const l of candidates) {
    if (bought >= CFG.nft.buysPerDay) break;
    try {
      // Verifikasi on-chain: listing masih ada, harga sama, seller masih pemilik.
      const onchain = await market$.listings(l.nft, l.tokenId, l.seller);
      const owner = await contract(l.nft, NFT_ABI).ownerOf(l.tokenId);
      if (onchain.quantity === 0n || onchain.pricePerItem !== BigInt(l.price) || lc(owner) !== lc(l.seller)) continue;
      const price = onchain.pricePerItem;
      if (!(await canSpend(price))) break;

      const name = `${cols.get(lc(l.nft)).name} #${l.tokenId}`;
      await sendTx(`Beli ${name} @ ${fmt(price)} HYPE`, market$.buyItems([{
        nftAddress: l.nft, tokenId: BigInt(l.tokenId), owner: l.seller, quantity: 1n,
        maxPricePerItem: price, paymentToken: l.paymentToken, usingNative: true,
      }], { value: price }));
      state.bought[`${lc(l.nft)}:${l.tokenId}`] = { price: price.toString(), at: Date.now() };
      saveState(state);
      bought++;
      report.push(`🛒 Beli ${name} @ ${fmt(price)} HYPE`);
      await humanDelay();

      await relist(market$, l.nft, l.tokenId, price, name, cols.get(lc(l.nft)), report);
      await humanDelay();
    } catch (e) {
      log(`⚠️ Gagal beli/list ${l.nft}#${l.tokenId}:`, e.shortMessage || e.message);
    }
  }
  if (!bought) report.push('🛒 Tidak ada NFT yang cocok dibeli hari ini');
}

async function relist(market$, nft, tokenId, buyPrice, name, col, report) {
  await ensureNftApproval(nft, NET.marketplace);
  const bps = BigInt(Math.round((1 + CFG.nft.markup) * 10_000));
  let price = (buyPrice * bps) / 10_000n;
  const minPrice = BigInt(col.minPrice || 0);
  if (price < minPrice) price = minPrice;
  const expiry = BigInt(now() + 14 * 86400);
  await sendTx(`List ${name} @ ${fmt(price)} HYPE`, market$.createOrUpdateListings([{
    nftAddress: nft, tokenId: BigInt(tokenId), quantity: 1n, pricePerItem: price,
    expirationTime: expiry, paymentToken: col.payToken || NET.marketWhype,
  }]));
  report.push(`🏷️ List ${name} @ ${fmt(price)} HYPE`);
}

/** Terima offer (token bid / collection bid) untuk NFT yang kita beli sebelumnya kalau harganya masuk. */
export async function runAcceptBids(market, state, report) {
  const market$ = contract(NET.marketplace, MARKET_ABI);
  const me = lc(wallet.address);
  const mine = market.tokens.filter((t) => lc(t.owner) === me);
  const colBySlug = new Map(market.collections.map((c) => [c.slug, c]));
  let sold = 0;

  for (const t of mine) {
    const col = colBySlug.get(t.slug);
    if (!col) continue;
    const rec = state.bought[`${lc(col.address)}:${t.tokenId}`];
    if (!rec) continue; // hanya NFT yang dibeli bot
    const floorOk = (BigInt(rec.price) * BigInt(Math.round(CFG.nft.acceptRatio * 10_000))) / 10_000n;

    const bids = market.bids
      .filter((b) => lc(b.nft) === lc(col.address) && b.funded && Number(b.expiration) > now() + 300 && lc(b.bidder) !== me)
      .filter((b) => (b.type === 'token' && String(b.tokenId) === String(t.tokenId)) || b.type === 'collection')
      .filter((b) => BigInt(b.price) >= floorOk)
      .sort((a, b) => (BigInt(a.price) > BigInt(b.price) ? -1 : 1));
    const bid = bids[0];
    if (!bid) continue;

    try {
      await ensureNftApproval(col.address, NET.marketplace);
      const name = `${col.name} #${t.tokenId}`;
      await sendTx(`Terima offer ${name} @ ${fmt(bid.price)} HYPE`, market$.acceptBids([{
        bidType: bid.type === 'collection' ? 1 : 0, nftAddress: col.address, tokenId: BigInt(t.tokenId),
        bidder: bid.bidder, quantity: 1n, pricePerItem: BigInt(bid.price), paymentToken: bid.paymentToken,
      }]));
      delete state.bought[`${lc(col.address)}:${t.tokenId}`];
      saveState(state);
      sold++;
      report.push(`🤝 Jual ${name} via offer @ ${fmt(bid.price)} WHYPE`);
      await humanDelay();
    } catch (e) {
      log(`⚠️ Gagal terima offer ${t.slug}#${t.tokenId}:`, e.shortMessage || e.message);
    }
  }
  if (sold) log(`🤝 ${sold} offer diterima`);
}

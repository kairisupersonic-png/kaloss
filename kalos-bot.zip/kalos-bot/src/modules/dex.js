import { CFG, NET } from '../config.js';
import { log, humanDelay } from '../util.js';
import { wallet, contract, provider, ROUTER_ABI, QUOTER_ABI, POOL_ABI, PM_ABI, ERC20_ABI, sendTx, canSpend, ensureErc20Approval, fmt, parse } from '../chain.js';
import { ethers } from 'ethers';

const deadline = () => BigInt(Math.floor(Date.now() / 1000) + 600);

async function poolInfo() {
  const p = new ethers.Contract(NET.dex.kalosWhypePool, POOL_ABI, provider);
  const [token0, token1, fee, spacing] = await Promise.all([p.token0(), p.token1(), p.fee(), p.tickSpacing()]);
  return { token0, token1, fee: Number(fee), spacing: Number(spacing) };
}

/** Swap HYPE -> KALOS (catatan: swap TIDAK menambah poin Kalos). */
export async function runSwap(report) {
  const amountIn = parse(CFG.dex.swapHype);
  if (!(await canSpend(amountIn))) return;
  const { fee } = await poolInfo();
  const quoter = contract(NET.dex.quoterV2, QUOTER_ABI);
  const [out] = await quoter.quoteExactInputSingle.staticCall({ tokenIn: NET.dex.whype, tokenOut: NET.dex.kalos, amountIn, fee, sqrtPriceLimitX96: 0n });
  const minOut = (out * BigInt(10_000 - CFG.dex.slippageBps)) / 10_000n;
  const router = contract(NET.dex.swapRouter, ROUTER_ABI);
  await sendTx(`Swap ${CFG.dex.swapHype} HYPE -> ~${fmt(out)} KALOS`, router.exactInputSingle({
    tokenIn: NET.dex.whype, tokenOut: NET.dex.kalos, fee, recipient: wallet.address,
    deadline: deadline(), amountIn, amountOutMinimum: minOut, sqrtPriceLimitX96: 0n,
  }, { value: amountIn }));
  report.push(`🔄 Swap ${CFG.dex.swapHype} HYPE -> ${fmt(out)} KALOS`);
}

/** Add liquidity full-range ke pool KALOS/WHYPE (TIDAK menambah poin Kalos). */
export async function runLp(report) {
  const hypeAmt = parse(CFG.dex.lpHype);
  if (!(await canSpend(hypeAmt * 2n))) return;
  const { token0, token1, fee, spacing } = await poolInfo();
  const whype = contract(NET.dex.whype, ERC20_ABI);
  const kalos = contract(NET.dex.kalos, ERC20_ABI);

  // Pastikan punya KALOS: swap setengah porsi kalau saldo kosong.
  if ((await kalos.balanceOf(wallet.address)) === 0n) { await runSwap(report); await humanDelay(); }
  await sendTx(`Wrap ${CFG.dex.lpHype} HYPE -> WHYPE`, whype.deposit({ value: hypeAmt }));

  const kalBal = await kalos.balanceOf(wallet.address);
  const whBal = await whype.balanceOf(wallet.address);
  const kalUse = kalBal / 2n; // pakai separuh KALOS, sisanya disimpan
  if (kalUse === 0n) { log('⚠️ KALOS kosong, LP dilewati'); return; }

  await ensureErc20Approval(NET.dex.kalos, NET.dex.positionManager, kalUse);
  await ensureErc20Approval(NET.dex.whype, NET.dex.positionManager, whBal);

  const maxTick = Math.floor(887272 / spacing) * spacing;
  const kalosIs0 = token0.toLowerCase() === NET.dex.kalos.toLowerCase();
  const pm = contract(NET.dex.positionManager, PM_ABI);
  await sendTx('Add liquidity KALOS/WHYPE (full range)', pm.mint({
    token0, token1, fee, tickLower: -maxTick, tickUpper: maxTick,
    amount0Desired: kalosIs0 ? kalUse : whBal, amount1Desired: kalosIs0 ? whBal : kalUse,
    amount0Min: 0n, amount1Min: 0n, recipient: wallet.address, deadline: deadline(),
  }));
  report.push(`💧 Add LP KALOS/WHYPE (~${CFG.dex.lpHype} HYPE)`);
}

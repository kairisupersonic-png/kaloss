import { CFG } from '../config.js';
import { log, humanDelay } from '../util.js';
import { wallet, contract, DROP_ABI, sendTx, canSpend, fmt, parse } from '../chain.js';

const ZERO_ROOT = '0x' + '0'.repeat(64);

/** Mint dari Drops yang sedang public (tanpa allowlist) dan harganya di bawah batas. */
export async function runDrops(market, report) {
  const max = parse(CFG.drops.maxPrice);
  const nowS = Math.floor(Date.now() / 1000);
  const drops = (market.drops || []).filter((d) => d.published && !d.paused && !d.mintPaused && !d.platformPaused && d.activePhaseIndex >= 0);
  let minted = 0;

  for (const d of drops) {
    const phase = d.phases?.[d.activePhaseIndex];
    if (!phase || phase.merkleRoot !== ZERO_ROOT) continue;
    if (Number(phase.startTime) > nowS || Number(phase.endTime) < nowS) continue;
    if (Number(phase.minted) >= Number(phase.maxSupply) || Number(d.minted) >= Number(d.supply)) continue;
    const price = BigInt(phase.price);
    if (price > max) continue;

    const qty = Math.max(1, Math.min(CFG.drops.qty, Number(phase.maxPerWallet) || 1));
    const drop = contract(d.address, DROP_ABI);
    try {
      const have = Number(await drop.balanceOf(wallet.address));
      if (phase.maxPerWallet && have >= Number(phase.maxPerWallet)) continue;
      const total = price * BigInt(qty);
      if (!(await canSpend(total))) break;
      await sendTx(`Mint ${qty}x ${d.slug} @ ${fmt(price)} HYPE`, drop.mint(BigInt(d.activePhaseIndex), qty, 0, [], { value: total }));
      report.push(`✨ Mint ${qty}x ${d.slug} (${fmt(total)} HYPE)`);
      minted++;
      await humanDelay();
    } catch (e) {
      log(`⚠️ Mint ${d.slug} gagal:`, e.shortMessage || e.message);
    }
  }
  if (!minted) report.push('✨ Tidak ada drop public yang cocok');
}

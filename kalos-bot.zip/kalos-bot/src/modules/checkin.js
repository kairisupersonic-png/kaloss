import { log } from '../util.js';

export async function runCheckin(api, report) {
  try {
    const r = await api.checkin();
    const streak = r?.streak ?? r?.checkin?.streak;
    log('📅 Check-in harian OK', streak != null ? `(streak ${streak})` : '');
    report.push(`📅 Check-in OK${streak != null ? `, streak ${streak}` : ''}`);
  } catch (e) {
    log('⚠️ Check-in gagal:', e.message);
    report.push(`⚠️ Check-in gagal: ${e.status || ''} ${e.data?.message || e.message}`.trim());
  }
}

import { CFG, NET } from './config.js';
import { log, sleep, rand, wibNow, loadState, saveState, telegram, humanDelay, shuffle } from './util.js';
import { wallet, balance, fmt } from './chain.js';
import { KalosApi } from './api.js';
import { runCheckin } from './modules/checkin.js';
import { runNftTrade, runAcceptBids } from './modules/nft.js';
import { runDrops } from './modules/drops.js';
import { runLikes, runPosts } from './modules/social.js';
import { runSwap, runLp } from './modules/dex.js';

const api = new KalosApi(wallet);
const args = new Set(process.argv.slice(2));

async function pointsLine() {
  try {
    const v = (await api.pointsRow('24h'))?.viewer;
    if (!v) return '📊 Belum ada poin tercatat (update tiap 07:00 WIB)';
    return `📊 Poin 24j: ${Number(v.daily?.points ?? v.points).toFixed(1)} (rank ${v.daily?.rank ?? v.rank}) · Season: ${Number(v.season?.points || 0).toFixed(1)} (rank ${v.season?.rank ?? '-'})`;
  } catch (e) { return `📊 Poin belum bisa dibaca (${e.message})`; }
}

async function status() {
  log(`👛 Wallet ${wallet.address}`);
  log(`💰 Saldo ${fmt(await balance())} HYPE`);
  try {
    const me = await api.me();
    const u = me?.profile?.username || me?.username;
    log(u ? `👤 Akun Kalos: @${u}` : '⚠️ Wallet belum terdaftar di Kalos. Daftar dulu lewat link referral di browser (connect wallet yang sama), lalu jalankan bot.');
  }
  catch (e) { log('⚠️ /v2/me:', e.message, '→ pastikan wallet sudah daftar lewat link referral di kalos.fun'); }
  log(await pointsLine());
}

async function runDaily() {
  const state = loadState();
  const report = [`🤖 Kalos Bot · ${wibNow().iso} WIB`, `👛 ${wallet.address.slice(0, 6)}…${wallet.address.slice(-4)}`];
  const start = await balance();
  log(`▶️ Mulai sesi harian. Saldo ${fmt(start)} HYPE`);

  if (start < BigInt(Math.round(CFG.minReserve * 1e18))) {
    const msg = `⛔ Saldo ${fmt(start)} HYPE di bawah cadangan. Isi test HYPE dulu: https://elysium.kinetiq.xyz/testnet-faucet`;
    log(msg); await telegram(msg); return;
  }

  if (CFG.enable.checkin) { await runCheckin(api, report); await humanDelay(); }

  let market = null;
  if (CFG.enable.nftTrade || CFG.enable.acceptBids || CFG.enable.drops) {
    try { market = await api.market(); } catch (e) { log('⚠️ Data market gagal:', e.message); }
  }

  // Urutan aksi diacak supaya pola tidak sama tiap hari.
  const tasks = [];
  if (market && CFG.enable.acceptBids) tasks.push(['acceptBids', () => runAcceptBids(market, state, report)]);
  if (market && CFG.enable.nftTrade) tasks.push(['nft', () => runNftTrade(market, state, report)]);
  if (market && CFG.enable.drops) tasks.push(['drops', () => runDrops(market, report)]);
  if (CFG.enable.likes) tasks.push(['likes', () => runLikes(api, report)]);
  if (CFG.enable.posts) tasks.push(['posts', () => runPosts(api, report)]);
  if (CFG.enable.swap) tasks.push(['swap', () => runSwap(report)]);
  if (CFG.enable.lp) tasks.push(['lp', () => runLp(report)]);

  for (const [name, fn] of shuffle(tasks)) {
    try { await fn(); } catch (e) { log(`❌ Modul ${name} error:`, e.shortMessage || e.message); report.push(`❌ ${name}: ${e.shortMessage || e.message}`); }
    await humanDelay();
  }

  const end = await balance();
  report.push(`💰 Saldo ${fmt(start)} → ${fmt(end)} HYPE`);
  report.push(await pointsLine());
  state.lastRunDate = wibNow().date;
  saveState(state);
  log('🏁 Sesi selesai\n' + report.join('\n'));
  await telegram(report.join('\n'));
}

/** Tunggu sampai jam acak di dalam jendela WIB hari ini (atau besok kalau sudah lewat). */
function nextRunDelayMs(alreadyRanToday) {
  const nowMs = Date.now();
  const wibMidnight = Math.floor((nowMs + 7 * 3600_000) / 86_400_000) * 86_400_000 - 7 * 3600_000;
  const pick = (dayOffset) => wibMidnight + dayOffset * 86_400_000 + rand(CFG.window.start, CFG.window.end) * 3600_000;
  let t = alreadyRanToday ? pick(1) : pick(0);
  if (t <= nowMs) t = alreadyRanToday ? pick(1) : nowMs + rand(1, 10) * 60_000;
  if (!alreadyRanToday && wibNow().hour >= CFG.window.end) t = pick(1);
  return t - nowMs;
}

async function main() {
  log(`🚀 Kalos Bot | chain ${NET.chainId} | wallet ${wallet.address}`);
  if (args.has('--status')) return status();
  if (args.has('--once')) return runDaily();

  await status();
  await telegram(`🚀 Kalos Bot aktif untuk ${wallet.address}`);
  for (;;) {
    const ran = loadState().lastRunDate === wibNow().date;
    const wait = nextRunDelayMs(ran);
    const at = new Date(Date.now() + wait + 7 * 3600_000).toISOString().replace('T', ' ').slice(0, 16);
    log(`⏰ Sesi berikutnya ${at} WIB`);
    await sleep(wait);
    try { await runDaily(); } catch (e) { log('❌ Sesi error:', e.message); await telegram('❌ Kalos Bot error: ' + e.message); }
  }
}

main().catch((e) => { log('❌ Fatal:', e.message); process.exit(1); });

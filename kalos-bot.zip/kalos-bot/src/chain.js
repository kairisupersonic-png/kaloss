import { ethers } from 'ethers';
import { CFG, NET } from './config.js';
import { log } from './util.js';

export const provider = new ethers.JsonRpcProvider(NET.rpc, NET.chainId, { staticNetwork: true });
export const wallet = new ethers.Wallet(CFG.privateKey, provider);
export const fmt = (wei) => Number(ethers.formatEther(wei)).toFixed(4);
export const parse = (hype) => ethers.parseEther(String(hype));

export const MARKET_ABI = [
  'function listings(address,uint256,address) view returns (uint64 quantity,uint128 pricePerItem,uint64 expirationTime,address paymentTokenAddress)',
  'function buyItems((address nftAddress,uint256 tokenId,address owner,uint64 quantity,uint128 maxPricePerItem,address paymentToken,bool usingNative)[] batch) payable',
  'function createOrUpdateListings((address nftAddress,uint256 tokenId,uint64 quantity,uint128 pricePerItem,uint64 expirationTime,address paymentToken)[] batch)',
  'function acceptBids((uint8 bidType,address nftAddress,uint256 tokenId,address bidder,uint64 quantity,uint128 pricePerItem,address paymentToken)[] batch)',
  'function getMinPriceForCollection(address) view returns (uint256)',
];
export const NFT_ABI = [
  'function ownerOf(uint256) view returns (address)',
  'function isApprovedForAll(address,address) view returns (bool)',
  'function setApprovalForAll(address,bool)',
];
export const DROP_ABI = [
  'function mint(uint256 phaseIndex,uint32 quantity,uint32 allowance,bytes32[] proof) payable',
  'function balanceOf(address) view returns (uint256)',
];
export const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
  'function deposit() payable',
];
export const ROUTER_ABI = [
  'function exactInputSingle((address tokenIn,address tokenOut,uint24 fee,address recipient,uint256 deadline,uint256 amountIn,uint256 amountOutMinimum,uint160 sqrtPriceLimitX96) params) payable returns (uint256 amountOut)',
];
export const QUOTER_ABI = [
  'function quoteExactInputSingle((address tokenIn,address tokenOut,uint256 amountIn,uint24 fee,uint160 sqrtPriceLimitX96) params) returns (uint256 amountOut,uint160 sqrtPriceX96After,uint32 initializedTicksCrossed,uint256 gasEstimate)',
];
export const POOL_ABI = [
  'function token0() view returns (address)', 'function token1() view returns (address)',
  'function fee() view returns (uint24)', 'function tickSpacing() view returns (int24)',
];
export const PM_ABI = [
  'function mint((address token0,address token1,uint24 fee,int24 tickLower,int24 tickUpper,uint256 amount0Desired,uint256 amount1Desired,uint256 amount0Min,uint256 amount1Min,address recipient,uint256 deadline) params) payable returns (uint256 tokenId,uint128 liquidity,uint256 amount0,uint256 amount1)',
];

export const contract = (addr, abi) => new ethers.Contract(addr, abi, wallet);

export async function balance() { return provider.getBalance(wallet.address); }

/** Cek saldo sebelum transaksi yang memakan HYPE. */
export async function canSpend(amountWei) {
  const bal = await balance();
  const ok = bal - amountWei >= parse(CFG.minReserve);
  if (!ok) log(`⛔ Saldo ${fmt(bal)} HYPE, tidak cukup untuk ${fmt(amountWei)} + cadangan ${CFG.minReserve}`);
  return ok;
}

export async function sendTx(label, promise) {
  const tx = await promise;
  log(`⏳ ${label}: ${NET.explorer}/tx/${tx.hash}`);
  const rc = await tx.wait();
  if (rc.status !== 1) throw new Error(`${label} gagal on-chain`);
  log(`✅ ${label} sukses`);
  return rc;
}

export async function ensureNftApproval(nft, operator) {
  const c = contract(nft, NFT_ABI);
  if (await c.isApprovedForAll(wallet.address, operator)) return;
  await sendTx('Approve NFT ke marketplace', c.setApprovalForAll(operator, true));
}

export async function ensureErc20Approval(token, spender, amount) {
  const c = contract(token, ERC20_ABI);
  if ((await c.allowance(wallet.address, spender)) >= amount) return;
  await sendTx('Approve token', c.approve(spender, ethers.MaxUint256));
}
